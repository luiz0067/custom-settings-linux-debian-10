clear
echo "criando icones";
sudo cp -R /etc/skel/* /home/usuario/

echo "removendo cd do repositório";
sed -i 's/deb cdrom/#deb cdrom/g'  /etc/apt/sources.list
echo "configurando flash";
echo "backup de arquivo freedesktop.org.xml original"
[ -f /usr/share/mime/packages/freedesktop.org.bkp ] &&  echo "bkp arquivo já criado" || cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp
sed -i 's/<mime-type type="application\/vnd.adobe.flash.movie">/\<mime-type type="application\/x-shockwave-flash">/g' /usr/share/mime/packages/freedesktop.org.xml
update-mime-database /usr/share/mime

echo "criando permissão arquivos";
chmod -R 7777 /opt/config_nite
chmod -R 7777 /opt/LigthBot
chmod -R 7777 /opt/LigthBot-2
chmod -R 7777 /opt/xlogo
chmod -R 7777 "/home/usuario/Área de trabalho"
chmod -R 7777 "/home/usuario/Imagens"

echo "adicionando repositorio teamviewer";
sh -c "echo 'deb http://linux.teamviewer.com/deb preview main' >> /etc/apt/sources.list.d/teamviewer.list"
echo "adicionando repositorio chrome";
sh -c 'echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list'

wget -q -O - https://dl.google.com/linux/linux_signing_key.pub |  apt-key add -
echo "adicionando chave chrome";
wget -q https://download.teamviewer.com/download/linux/signature/TeamViewer2017.asc -O- |  apt-key add -
echo "adicionando chave teamviewer";

echo "Instalando aplicativos";
apt-get update && apt-get install sudo gnome-tweak-tool vim gcompris scratch  tuxmath tuxpaint pysiogame pysycache knetwalk audacity openshot kolourpaint4 gnash screenfetch teamviewer google-chrome-stable firmware-linux-free
echo "aplicativos prontos";
#echo "GRUB_GFXMODE=1024x768"         >> /etc/default/grub
#echo "GRUB_GFXMODE=1360x768"         >> /etc/default/grub  
#echo "GRUB_GFXPAYLOAD_LINUX=1024x768" >> /etc/default/grub
#echo "GRUB_GFXPAYLOAD_LINUX=1360x768" >> /etc/default/grub  
#sudo update-grub
rm -rf "/home/usuario/Área de trabalho/scripts"
sudo usermod -aG sudo usuario
su - usuario
sudo whoami
echo "politica de super usuário";
cd ~/.local/share/keyrings/
sudo rm login.keyring
echo "abra o google chrome ... quando pedir senha deixe em branco";
sh /opt/config_nite/default.sh

bash firefox /opt/LigthBot/src.swf
[ -f /home/usuario/.mozilla/firefox/ ] &&  cd "/home/usuario/" || cd "/home/usuario/"
cd .mozilla/firefox/
cd $(ls | grep -E '\.default$')
ls
sed -i 's/user_pref("plugins.http_https_only", true);/user_pref("plugins.http_https_only", false);/g' ./prefs.js
echo "atualiza as configurações do firefox para abrir o LigthBot na maquina local"
bash firefox /opt/LigthBot/src.swf
### abra o google chrome ... quando pedir senha deixe em branco
sudo reboot


