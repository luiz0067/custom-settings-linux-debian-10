
echo "GRUB_GFXMODE=1024x768"         >> /etc/default/grub
#echo "GRUB_GFXMODE=1360x768"         >> /etc/default/grub  
echo "GRUB_GFXPAYLOAD_LINUX=1024x768" >> /etc/default/grub
#echo "GRUB_GFXPAYLOAD_LINUX=1360x768" >> /etc/default/grub  
sudo update-grub

