[ -f /usr/share/mime/packages/freedesktop.org.bkp ] && echo cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp || echo "Not found"
sed -i 's/<mime-type type="application\/vnd.adobe.flash.movie">/\<mime-type type="application\/x-shockwave-flash">/g' /usr/share/mime/packages/freedesktop.org.xml
update-mime-database /usr/share/mime
#atualiza mime types para abrir swf no firefox


cd "/home/aluno/.mozilla/firefox/"$(ls | grep -E '\.default$')
cd $(ls | grep -E '\.default$')
ls
sed -i 's/user_pref("plugins.http_https_only", true);/user_pref("plugins.http_https_only", false);/g' ./prefs.js
# atualiza as configurações do firefox para abrir o LigthBot na maquina local


chmod -R 7777 "/etc/skel"
cp -R /etc/skel/* /home/aluno/
chmod -R 7777 "/home/aluno/Área de trabalho" 
chmod -R 7777 "/home/aluno/Imagens" 
chmod -R 7777 "/etc/profile"
chmod -R 7777 "/opt/LigthBot"
chmod -R 7777 "/opt/LigthBot-2"
chmod -R 7777 "/opt/xlogo"
chmod -R 7777 "/opt/config_nite"
#permissões em aquivos e pastas

sed -i 's/deb cdrom/#deb cdrom/g' /etc/apt/sources.list
#comenta para que não pegue nada de repositórios do cd-rom/pen drive
#sed -i 's/stretch/buster/g' /etc/apt/sources.list 
#muda de debian stretch 9 para debian buster 10
#sh -c 'echo "deb http://ftp.de.debian.org/debian stretch main " >> /etc/apt/sources.list' 
#adiciona uma linha de repositório 9 stretch por causa do gnash

sh -c "echo 'deb http://linux.teamviewer.com/deb preview main' >> /etc/apt/sources.list.d/teamviewer.list"
#repositorio externo teamviewer  
sh -c 'echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list'
#repositorio externo google chrome  
wget -q -O - https://dl.google.com/linux/linux_signing_key.pub |  apt-key add -
#chave repositório google chrome
wget -q https://download.teamviewer.com/download/linux/signature/TeamViewer2017.asc -O- |  apt-key add -
#chave repositório teamviewer

apt-get update 
apt-get upgrade 
apt-get dist-upgrade 
apt-get install sudo gnome-tweak-tool vim gcompris scratch  tuxmath tuxpaint pysiogame pysycache knetwalk audacity openshot kolourpaint4 screenfetch teamviewer google-chrome-stable firmware-linux-free dialog pv #gnash
dpkg --configure -a
apt-get -f install
apt-get install linux-headers-$(uname -r)
# todos os aplicativos educacionais


wget https://raw.githubusercontent.com/cybernova/fireflashupdate/master/fireflashupdate.sh
chmod +x fireflashupdate.sh
./fireflashupdate.sh
#instalação de flash segundo debian wiki


#echo "GRUB_GFXMODE=1024x768"         >> /etc/default/grub
#echo "GRUB_GFXMODE=1360x768"         >> /etc/default/grub  
#echo "GRUB_GFXPAYLOAD_LINUX=1024x768" >> /etc/default/grub
#echo "GRUB_GFXPAYLOAD_LINUX=1360x768" >> /etc/default/grub  
#sudo update-grub
# resolução de tela debian 9 para 8 geração de APU intel não identificada


sudo usermod -aG sudo aluno
su - aluno
sudo whoami
#permissão usuario root equivalente root

cd ~/.local/share/keyrings/
sudo rm login.keyring
#remover chaveiro do chrome

rm -rf "/home/aluno/Área de trabalho/scripts/"
#remover scripts
sudo reboot
#reinicia

