[ -f /usr/share/mime/packages/freedesktop.org.bkp ] && echo cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp || echo "Not found"

sed -i 's/<mime-type type="application\/vnd.adobe.flash.movie">/\<mime-type type="application\/x-shockwave-flash">/g' /usr/share/mime/packages/freedesktop.org.xml
update-mime-database /usr/share/mime
apt-get install linux-headers-$(uname -r)
cd "/home/aluno/.mozilla/firefox/"$(ls | grep -E '\.default$')
cd $(ls | grep -E '\.default$')
ls
sed -i 's/user_pref("plugins.http_https_only", true);/user_pref("plugins.http_https_only", false);/g' ./prefs.js

cp -R /etc/skel/* /home/aluno/
chmod -R +x "/home/aluno/Área de trabalho/"
chmod 7777 "/home/aluno/Área de trabalho/scripts/"
chmod  7777 /opt/config_nite/default.sh 
sed -i 's/deb cdrom/#deb cdrom/g' /etc/apt/sources.list
#sed -i 's/stretch/buster/g' /etc/apt/sources.list
#sh -c 'echo "deb http://ftp.de.debian.org/debian stretch main " >> /etc/apt/sources.list' 

sh -c "echo 'deb http://linux.teamviewer.com/deb preview main' >> /etc/apt/sources.list.d/teamviewer.list"
sh -c 'echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list'

wget -q -O - https://dl.google.com/linux/linux_signing_key.pub |  apt-key add -
wget -q https://download.teamviewer.com/download/linux/signature/TeamViewer2017.asc -O- |  apt-key add -

apt-get update 
apt-get upgrade 
apt-get dist-upgrade 
apt-get install sudo gnome-tweak-tool vim gcompris scratch  tuxmath tuxpaint pysiogame pysycache knetwalk audacity openshot kolourpaint4 screenfetch teamviewer google-chrome-stable firmware-linux-free dialog pv 
dpkg --configure -a
apt-get -f install
apt-get install linux-headers-$(uname -r)



wget https://raw.githubusercontent.com/cybernova/fireflashupdate/master/fireflashupdate.sh
chmod +x fireflashupdate.sh
./fireflashupdate.sh

chmod -R 7777 "/home/aluno/Área de trabalho" 
chmod -R 7777 "/home/aluno/Imagens" 
chmod -R 7777 "/etc/profile"
chmod -R 7777 "/opt/LigthBot"
chmod -R 7777 "/opt/LigthBot-2"
chmod -R 7777 "/opt/xlogo"
chmod -R 7777 "/opt/config_nite"

#echo "GRUB_GFXMODE=1024x768"         >> /etc/default/grub
#echo "GRUB_GFXMODE=1360x768"         >> /etc/default/grub  
#echo "GRUB_GFXPAYLOAD_LINUX=1024x768" >> /etc/default/grub
#echo "GRUB_GFXPAYLOAD_LINUX=1360x768" >> /etc/default/grub  
#sudo update-grub
rm -rf "/home/aluno/Área de trabalho/scripts/"
sudo usermod -aG sudo aluno
su - aluno
sudo whoami
cd ~/.local/share/keyrings/

sudo rm login.keyring
sudo reboot


