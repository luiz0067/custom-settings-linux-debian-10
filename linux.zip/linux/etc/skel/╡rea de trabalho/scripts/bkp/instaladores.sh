#configuração de usuarios
su root
passwd kaderno
apt-get install sudo
sudo adduser aluno
usermod -aG sudo aluno
su - aluno
sudo whoami

#autologin
sudo cp /etc/lightdm/lightdm.conf /etc/lightdm/lightdm.bkp
sudo leafpad /etc/lightdm/lightdm.conf
[Seat:*]
utologin-guest=true
autologin-user=aluno
autologin-user-timeout=0

#educacional
sudo apt-get install scratch tuxmath gcompris pysiogame gnash pv dialog gedit alien


#flash em lxde no firefox
sudo nano /etc/apt/source.list
deb http://www.deb-multimedia.org stretch main non-free
deb http://ftp.de.debian.org/debian jessie main contrib

sudo apt-get update
sudo apt-get install deb-multimedia-keyring
sudo apt-get install flashplayer-chromium
sudo apt-get install flashplugin-nonfree 
firefox about:config
pesquise
plugins.http_https_only
valor false


sudo cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp
sudo gedit /usr/share/mime/packages/freedesktop.org.xml 
<mime-type type="application/vnd.adobe.flash.movie">
<mime-type type="application/x-shockwave-flash">
sudo update-mime-database /usr/share/mime

#clonager
(pv -n /dev/sda | dd of=/dev/sdb bs=4096 conv=notrunc,noerror,sync) 2>&1 | dialog --gauge "Running dd command (cloning), please wait..." 10 70 0

dd if=/dev/sdd1 of=/dev/sdd2 bs=4096 conv=notrunc,noerror,sync status=progress

dd if=/dev/sdd1 | pv | dd of=/dev/sdd2 bs=4096 conv=notrunc,noerror,sync status=progress
