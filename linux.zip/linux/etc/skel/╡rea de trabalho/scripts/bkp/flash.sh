apt-get install -f alien
dpkg --configure -a
apt-get -f install
apt-get install -f alien
wget https://fpdownload.adobe.com/pub/flashplayer/pdc/32.0.0.223/flash-player-npapi-32.0.0.223-release.x86_64.rpm
alien -i ./*.rpm
rm *.rpm
cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp
cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp2
cp /usr/share/mime/packages/freedesktop.org.xml /usr/share/mime/packages/freedesktop.org.bkp3
sed -i 's/<mime-type type="application\/vnd.adobe.flash.movie">/\<mime-type type="application\/x-shockwave-flash">/g' /usr/share/mime/packages/freedesktop.org.xml
update-mime-database /usr/share/mime
apt-get install linux-headers-$(uname -r)
cd "/home/aluno/.mozilla/firefox/"$(ls | grep -E '\.default$')
cd $(ls | grep -E '\.default$')
ls
sed -i 's/user_pref("plugins.http_https_only", true);/user_pref("plugins.http_https_only", false);/g' ./prefs.js
#firefox about:config
#prefs.js
#pesquise
#plugins.http_https_only
#valor false

