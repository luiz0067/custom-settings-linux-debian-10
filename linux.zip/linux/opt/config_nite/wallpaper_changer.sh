#!/bin/bash
DIR="/opt"
PIC=$(ls $DIR/NITE7.png | shuf -n1)
gsettings set org.mate.background picture-filename "$PIC"
gsettings set org.mate.background picture-options "stretched"
#sleep 1000
#while true; do
#done 
