#!/bin/bash
DIR="/opt/wallpaper"
PIC=$(ls $DIR/NITE7.png | shuf -n1)
gsettings set org.mate.background picture-filename "$PIC"
gsettings set org.mate.background picture-options "stretched"
dconf dump /org/mate/panel/ > /opt/config_nite/panel_bkp.conf
dconf load /org/mate/panel/ < /opt/config_nite/panel_bkp.conf


#gsettings list-recursively org.mate.panel.toplevel:/org/mate/panel/toplevels/top/
#gsettings list-recursively org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ x 0

#gsettings set org.mate.panel confirm-panel-remove true
#gsettings set org.mate.panel locked-down false
#gsettings set org.mate.panel default-layout 'default'
#gsettings set org.mate.panel object-id-list ['menu-bar', 'notification-area', 'clock']
#gsettings set org.mate.panel toplevel-id-list ["top","bottom"]
#gsettings set org.mate.panel disable-force-quit false
#gsettings set org.mate.panel drawer-autoclose true
#gsettings set org.mate.panel enable-program-list true
#gsettings set org.mate.panel enable-autocompletion true
#gsettings set org.mate.panel enable-animations true
#gsettings set org.mate.panel tooltips-enabled true
#gsettings set org.mate.panel disabled-applets @as []
#gsettings set org.mate.panel history-mate-run @as []
#gsettings set org.mate.panel show-program-list false
#gsettings set org.mate.panel highlight-launchers-on-mouseover true

#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ animation-speed 'fast'
##gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ y 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ orientation 'top'
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ unhide-delay 100
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ y-centered false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ auto-hide false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ enable-buttons false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ expand true
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ name ''
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ y-bottom -1
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ hide-delay 300
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ size 400
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ enable-arrows true
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ screen 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ auto-hide-size 1
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ monitor 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ enable-animations true
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ x-right -1
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ x-centered false

#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background image ''
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background fit false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background opacity 6000
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background rotate false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background stretch false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background color '#ffffff'
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/bottom/ background type 'none'


#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ x 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ animation-speed 'fast'
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ y 742
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ orientation 'bottom'
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ unhide-delay 100
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ y-centered false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ auto-hide false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ enable-buttons false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ expand true
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ name ''
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ y-bottom 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ hide-delay 300
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ size 24
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ enable-arrows true
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ screen 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ auto-hide-size 1
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ monitor 0
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ enable-animations true
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ x-right -1
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ x-centered false#

#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background image ''
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background fit false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background opacity 6000
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background rotate false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background stretch false
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background color '#ffffff'
#gsettings set org.mate.panel.toplevel:/org/mate/panel/toplevels/top/ background type 'none'
#sleep 1000
#while true; do
#done 

#gsettings list-recursively org.mate.panel
#gsettings list-recursively org.mate.panel.object:/org/mate/panel/objects/top/
#gsettings get org.mate.panel object-id-list
#gsettings list-recursively org.mate.panel.object:/org/mate/panel/objects/toplevel-0/
#gsettings list-recursively org.mate.panel.toplevel:/org/mate/panel/toplevels/top/
