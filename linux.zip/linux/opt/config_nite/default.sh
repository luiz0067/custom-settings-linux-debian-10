#!/bin/bash
dconf write /org/mate/caja/desktop/trash-icon-visible true
dconf write /org/mate/caja/desktop/computer-icon-visible true

DIR="/opt/config_nite/wallpaper"
PIC=$(ls $DIR/NITE7.png | shuf -n1)
gsettings set org.mate.background picture-filename "$PIC"
gsettings set org.mate.background picture-options "stretched"
#dconf dump /org/mate/panel/ > /opt/config_nite/panel_bkp.conf
dconf load /org/mate/panel/ < /opt/config_nite/panel_bkp.conf
#painel

gsettings set  org.mate.screensaver themes "['screensavers-engine']"
# protecao de tela

gsettings set org.mate.screensaver lock-enabled false
# bloqueia a tela quando a proteção de tela estiver ativa



gsettings set apps.light-locker lock-on-suspend false
# bloqueia a tela quando o computador estiver suspenso


gsettings set org.mate.power-manager sleep-computer-ac 0
# tempo para supender


gsettings set org.mate.power-manager sleep-display-ac 0
# tempo para desligar o monitor

#sleep 1000
#while true; do
#done 

echo "politica de super usuário";
cd ~/.local/share/keyrings/
sudo rm login.keyring
echo "abra o google chrome ... quando pedir senha deixe em branco";
sh /opt/config_nite/default.sh

bash firefox /opt/LigthBot/src.swf
[ -f /home/usuario/.mozilla/firefox/ ] &&  cd "/home/usuario/" || cd "/home/professor/"
cd .mozilla/firefox/
cd $(ls | grep -E '\.default$')
ls
sed -i 's/user_pref("plugins.http_https_only", true);/user_pref("plugins.http_https_only", false);/g' ./prefs.js
echo "atualiza as configurações do firefox para abrir o LigthBot na maquina local"
bash firefox /opt/LigthBot/src.swf
### abra o google chrome ... quando pedir senha deixe em branco

